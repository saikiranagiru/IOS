//
//  ViewController.swift
//  DiscountTwo
//
//  Created by student on 4/7/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var AmountOutlet: UITextField!
    
    
    @IBOutlet weak var DiscountRate: UITextField!
    
    var priceafterDisc = 0.0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func CalculateClick(_ sender: UIButton) {
        
        var amount = Double (AmountOutlet.text!)
        
        var DiscountRate = Double(DiscountRate.text!)
        
        priceafterDisc = amount! - (amount! * DiscountRate!/100)
        
        
        
        
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        var destination = segue.identifier
        if destination == "ResultSegue"{
            var identifier = segue.destination as! ResultViewController
            
            identifier.amount = AmountOutlet.text!
            
            identifier.disc = DiscountRate.text!
            
            identifier.final = String(priceafterDisc)
            
            
        }
    }
    

}

