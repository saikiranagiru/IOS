//
//  ResultViewController.swift
//  DiscountTwo
//
//  Created by student on 4/7/22.
//

import UIKit

class ResultViewController: UIViewController {
    
    
    @IBOutlet weak var AmountOut: UILabel!
    
    @IBOutlet weak var DiscountOut: UILabel!
    
    @IBOutlet weak var PriceOut: UILabel!
    
    var amount = ""
    var disc = ""
    var final = ""

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        AmountOut.text = AmountOut.text! + amount
        DiscountOut.text = DiscountOut.text! + disc
        PriceOut.text! = PriceOut.text! + final
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
