//
//  MovieCollectionViewCell.swift
//  Agiru_Movies
//
//  Created by Agiru,Sai Kiran on 4/21/22.
//

import UIKit

class MovieCollectionViewCell: UICollectionViewCell {
    
}
